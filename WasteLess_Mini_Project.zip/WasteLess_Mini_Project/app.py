from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import date, datetime

app = Flask(__name__)
app.secret_key = "wasteless-mini-project"

# Simple in-memory storage. Items reset when the server restarts.
food_items = []
next_id = 1

def get_status(expiry_date):
    """Return a simple status based on the recorded expiry date."""
    days_left = (expiry_date - date.today()).days
    if days_left < 0:
        return "Expired"
    if days_left <= 3:
        return "Expiring Soon"
    return "Fresh"

def get_suggestion(item):
    status = get_status(item["expiry_date"])
    if status == "Expired":
        return "Check the label and condition; do not consume food that may be unsafe."
    if status == "Expiring Soon":
        return "Prioritize this item soon if it is still safe and suitable to eat."
    return "Store it correctly and check it again before the expiry date."

@app.route("/")
def index():
    # Keep the display ordered by the closest expiry date.
    ordered_items = sorted(food_items, key=lambda item: item["expiry_date"])
    for item in ordered_items:
        item["status"] = get_status(item["expiry_date"])
        item["suggestion"] = get_suggestion(item)

    total = len(ordered_items)
    expiring = sum(1 for item in ordered_items if item["status"] == "Expiring Soon")
    expired = sum(1 for item in ordered_items if item["status"] == "Expired")
    fresh = sum(1 for item in ordered_items if item["status"] == "Fresh")

    return render_template(
        "index.html",
        items=ordered_items,
        total=total,
        expiring=expiring,
        expired=expired,
        fresh=fresh,
        today=date.today().isoformat()
    )

@app.route("/add", methods=["GET", "POST"])
def add_item():
    global next_id

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        quantity = request.form.get("quantity", "").strip()
        expiry_text = request.form.get("expiry_date", "").strip()

        if not name or not quantity or not expiry_text:
            flash("Please fill in every field.", "error")
            return render_template("add_item.html", today=date.today().isoformat())

        try:
            expiry_date = datetime.strptime(expiry_text, "%Y-%m-%d").date()
        except ValueError:
            flash("Please enter a valid expiry date.", "error")
            return render_template("add_item.html", today=date.today().isoformat())

        if expiry_date < date.today():
            # Past dates are allowed so users can record already-expired items.
            flash("This date is in the past, so the item will be marked as expired.", "warning")

        food_items.append({
            "id": next_id,
            "name": name,
            "quantity": quantity,
            "expiry_date": expiry_date
        })
        next_id += 1
        flash(f"{name} was added to your inventory.", "success")
        return redirect(url_for("index"))

    return render_template("add_item.html", today=date.today().isoformat())

@app.route("/used/<int:item_id>", methods=["POST"])
def mark_used(item_id):
    global food_items
    matching_item = next((item for item in food_items if item["id"] == item_id), None)
    if matching_item:
        food_items = [item for item in food_items if item["id"] != item_id]
        flash(f'{matching_item["name"]} was removed from the active inventory.', "success")
    else:
        flash("Food item was not found.", "error")
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
