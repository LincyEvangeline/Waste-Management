# WasteLess – Smart Food Waste Reduction System

A beginner-friendly mini project built with Python, Flask, HTML, and CSS.

## Features
- Add food name, quantity, and expiry date
- Dashboard counts for total, fresh, expiring-soon, and expired items
- Automatic status calculation using today's date
- Simple food-saving tips
- Mark consumed items as used to remove them from the active inventory
- Responsive layout for desktop and mobile

## Requirements
- Python 3.10 or newer
- VS Code (recommended)
- Internet connection only if you want the optional Google Fonts to load; the app itself works without it

## Run in VS Code
1. Extract the ZIP file.
2. Open the `WasteLess_Mini_Project` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment (recommended):
   - Windows: `py -m venv .venv`
   - Activate it: `.venv\\Scripts\\activate`
5. Install Flask: `python -m pip install -r requirements.txt`
6. Start the application: `python app.py`
7. Open the local address shown in the terminal, usually `http://127.0.0.1:5000`.

If `py` is not recognized, try `python -m venv .venv`. If activation is blocked in PowerShell, use Command Prompt terminal or run `.venv\\Scripts\\python.exe -m pip install -r requirements.txt` and `.venv\\Scripts\\python.exe app.py`.

## Important limitation
This starter version stores items in memory. The inventory is cleared when the Python server restarts. A next version could use SQLite for permanent storage and user accounts.

## Food safety note
The app uses the date entered by the user to classify records; it does not inspect food or determine whether it is safe to eat. Follow package instructions and local food-safety guidance.
