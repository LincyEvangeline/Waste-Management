# WasteLess – Smart Food Waste Reduction System
## Mini Project Report

### 1. Abstract
Food waste happens when food is forgotten, purchased in excess, or not used before its expiry date. WasteLess is a small web application developed with Python, Flask, HTML, and CSS. It allows users to record food names, quantities, and expiry dates. The dashboard classifies items as Fresh, Expiring Soon, or Expired and offers simple food-saving tips. The project aims to encourage better food planning and reduce avoidable household food waste.

### 2. Problem Statement
People may forget stored food and its expiry date, which can lead to unnecessary food waste. Keeping records manually is inconvenient. A simple digital system is needed to track food items and highlight items that need attention.

### 3. Objectives
- Record food items and quantities.
- Store an expiry date for each item.
- Identify items that are expired or nearing expiry.
- Encourage users to use older items first.
- Provide a simple and easy-to-use web interface.

### 4. Existing System
Food is often tracked by memory, paper notes, or labels. These methods do not provide a single dashboard and reminders can be missed.

### 5. Proposed System
WasteLess presents a browser-based dashboard. Users add food details through a form. Python calculates the status based on the recorded expiry date. Users can mark items as used when they have consumed them.

### 6. Hardware and Software Requirements
**Hardware:** Computer or laptop, 4 GB RAM recommended, keyboard, display, and internet access for initial package installation.

**Software:** Windows/macOS/Linux, Python 3.10+, VS Code (recommended), Flask, HTML5, CSS3, and a modern web browser.

### 7. Modules
1. Dashboard – shows inventory summary.
2. Food Entry – accepts food name, quantity, and expiry date.
3. Expiry Monitoring – classifies items based on the date.
4. Food-Saving Tips – displays practical suggestions.
5. Mark as Used – removes consumed items from the active inventory.

### 8. System Architecture
User → Web Browser (HTML/CSS) → Flask Routes (Python) → In-memory Food List → Status Calculation → Dashboard Response.

### 9. Algorithm
1. Start the application.
2. Display the dashboard.
3. If the user chooses Add Food, display the entry form.
4. Validate the food name, quantity, and expiry date.
5. Add the food record to the inventory.
6. Compare the expiry date with today's date.
7. If the date is earlier than today, label it Expired.
8. If the date is within the next three days, label it Expiring Soon.
9. Otherwise, label it Fresh.
10. Display the updated inventory and summary.
11. If the user marks an item as used, remove it from the active inventory.
12. Stop when the application server is shut down.

### 10. Testing
| Test case | Input/action | Expected result |
|---|---|---|
| Open dashboard | Visit `/` | Dashboard appears |
| Add valid item | Name, quantity, valid date | Item appears in inventory |
| Missing field | Leave one field empty | Validation message appears |
| Expired item | Enter a past date | Status is Expired |
| Soon-to-expire item | Enter today through three days from today | Status is Expiring Soon |
| Fresh item | Enter a date more than three days away | Status is Fresh |
| Mark as used | Click Mark used | Item disappears from active list |
| Empty inventory | Start with no items | Empty-state message appears |

### 11. Advantages
- Easy for beginners to understand.
- Clear visual summary.
- Encourages food planning.
- Works in a web browser.
- Does not require a database for the demonstration version.

### 12. Limitations and Future Enhancements
The current version stores data in memory, so records are lost after restarting the server. It does not send automatic notifications or verify food safety. Future improvements can include SQLite storage, login, email reminders, barcode scanning, recipe recommendations, and food donation information.

### 13. Conclusion
WasteLess demonstrates how a simple web application can help users keep track of stored food. By recording expiry dates and highlighting items that need attention, it encourages users to plan meals and reduce avoidable food waste. The project also demonstrates the use of Python, Flask routes, HTML forms, CSS styling, and date-based logic.

### 14. Viva Questions and Answers
**1. What is WasteLess?**  
WasteLess is a web application for tracking food items and their expiry dates.

**2. What is Python used for?**  
Python handles the application logic, form processing, and expiry-status calculation.

**3. What is Flask?**  
Flask is a lightweight Python web framework used to create web applications.

**4. What is HTML used for?**  
HTML defines the structure and content of web pages.

**5. What is CSS used for?**  
CSS controls the visual design, layout, spacing, and colours.

**6. What is a route in Flask?**  
A route connects a URL to a Python function.

**7. How is expiry status calculated?**  
The program compares the recorded expiry date with today's date.

**8. What does “Expiring Soon” mean in this project?**  
It means the recorded expiry date is today or within the next three days.

**9. Does this version use a database?**  
No. It uses an in-memory Python list for a simple demonstration.

**10. What happens when the server restarts?**  
The in-memory food records are cleared.

**11. How can data be saved permanently?**  
A database such as SQLite can be added.

**12. What is the main benefit of this project?**  
It helps users notice food items that need attention and plan their use.

**13. Is this an AI project?**  
No. This version uses rule-based date comparisons, not AI.

**14. What is a future enhancement?**  
Automatic reminders, permanent database storage, barcode scanning, or recipe suggestions.

**15. Does an expiry date alone prove food is unsafe?**  
No. The app only classifies the entered date; users must follow package instructions and food-safety guidance.
